// server.js — PHQ-9 Companion (Express + static React build, CommonJS)

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const DEFAULT_MODEL = process.env.OPENAI_MODEL || 'gpt-5-chat-latest';

// ---------- Serve static React build ----------
// __dirname is already .../server, so public is just ./public
const buildPath = path.join(__dirname, 'public');
if (fs.existsSync(buildPath)) {
  app.use(express.static(buildPath));
  console.log('✅ Serving static files from', buildPath);
} else {
  console.error('⚠️  React build not found at', buildPath);
}

// ---------- Health checks ----------
app.get('/health', (_req, res) => res.json({ ok: true, model: DEFAULT_MODEL }));
app.get('/api/llm', (_req, res) =>
  res.status(405).send('Use POST /api/llm with body: { "messages": [ { role, content }, ... ] }')
);

// ---------- Helper: extract LLM reply ----------
function extractReply(d) {
  // 1) Responses API convenience field
  if (typeof d?.output_text === 'string' && d.output_text.trim()) return d.output_text.trim();

  // 2) Structured output[].content[].text
  if (Array.isArray(d?.output)) {
    const txt = d.output
      .flatMap((item) => (item?.content || []).map((part) => part?.text).filter(Boolean))
      .join(' ')
      .trim();
    if (txt) return txt;
  }

  // 3) Completions-like fallback
  const choiceMsg = d?.choices?.[0]?.message?.content;
  if (typeof choiceMsg === 'string' && choiceMsg.trim()) return choiceMsg.trim();

  return null;
}

// ---------- Crisis keyword detection ----------
const RISK_PATTERNS = [
  'suicide',
  'kill myself',
  'end my life',
  'self-harm',
  'self harm',
  'hurt myself',
  'take my life',
  'better off dead',
];
function containsRiskLanguage(s) {
  const t = (s || '').toLowerCase();
  return RISK_PATTERNS.some((p) => t.includes(p));
}

// ---------- Main LLM route ----------
app.post('/api/llm', async (req, res) => {
  try {
    if (!OPENAI_API_KEY) {
      console.error('❌ Missing OPENAI_API_KEY');
      return res.status(500).send('Missing OPENAI_API_KEY');
    }

    const { messages = [] } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0)
      return res.status(400).json({ error: '"messages" array required' });

    // Simple guardrail for interactive content
    const riskText = messages.filter((m) => m.role === 'user').map((m) => m.content).join('\n');
    if (containsRiskLanguage(riskText)) {
      return res.json({
        reply: 'If you’re in the U.S., call 988 (or 911 if in immediate danger).',
      });
    }

    // Prepend a light system prompt
    const input = [
      { role: 'system', content: 'You are PHQ-9 Companion, a non-diagnostic wellbeing guide.' },
      ...messages,
    ];

    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: DEFAULT_MODEL,
        input,
        max_output_tokens: 220,
        temperature: 0.35,
      }),
    });

    if (!r.ok) {
      const text = await r.text();
      console.error('❌ OpenAI API error', r.status, text);
      return res.status(r.status).type('text').send(text);
    }

    const data = await r.json();
    const reply = extractReply(data) || 'No response.';
    res.json({ reply });
  } catch (err) {
    console.error('💥 /api/llm error', err);
    res.status(500).send('Server error');
  }
});

// ---------- SPA fallback (send index.html) ----------
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).send('Not found');
  res.sendFile(path.join(buildPath, 'index.html'));
});

// ---------- Start ----------
const PORT = process.env.PORT || 8080; // Azure expects 8080 in Linux containers
app.listen(PORT, () => {
  console.log(`✅ PHQ-9 Companion running on port ${PORT}, model=${DEFAULT_MODEL}`);
});
